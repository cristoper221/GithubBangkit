package com.dicoding.picodiploma.githubuserone

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.picodiploma.githubuserone.databinding.ItemRowUserBinding

class ListUserAdapater (private val listUser: ArrayList<User>): RecyclerView.Adapter<ListUserAdapater.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ListViewHolder {
        val binding = ItemRowUserBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(binding)
    }



    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (name, username, avatar, company) = listUser[position]
        holder.imgAvatar.setImageResource(avatar)
        holder.tvName.text = name
        holder.tvuserName.text = username
        holder.tvCompany.text = company
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listUser[holder.adapterPosition]) }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: User)
    }

    override fun getItemCount(): Int = listUser.size

    inner class ListViewHolder(var binding: ItemRowUserBinding) : RecyclerView.ViewHolder(binding.root) {

        var imgAvatar: ImageView = itemView.findViewById(R.id.img_avatar)
        var tvName: TextView = itemView.findViewById(R.id.tv_name)
        var tvuserName : TextView = itemView.findViewById(R.id.tv_username)
        var tvCompany : TextView = itemView.findViewById(R.id.tv_company)

    }

}

