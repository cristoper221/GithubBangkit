package com.dicoding.picodiploma.githubuserone

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.picodiploma.githubuserone.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private val list = ArrayList<User>()
    private lateinit var adapter : ListUserAdapater
    private lateinit var viewModel : MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.Theme_GithubUserOne)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        binding.rvUser.setHasFixedSize(true)
        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)
        list.addAll(listUser)
        showRecycleList()
        setContentView(binding.root)

    }


    private val listUser: ArrayList<User>
    get(){
        val dataName = resources.getStringArray(R.array.name)
        val dataUserName = resources.getStringArray(R.array.username)
        val dataAvatar = resources.obtainTypedArray(R.array.avatar)
        val dataLocation = resources.getStringArray(R.array.location)
        val dataRepository = resources.getStringArray(R.array.repository)
        val dataCompany = resources.getStringArray(R.array.company)
        val dataFollowers = resources.getStringArray(R.array.followers)
        val dataFollowing = resources.getStringArray(R.array.following)


        val listUser = ArrayList<User>()
        for (i in dataName.indices){
            val user = User(dataName[i], dataUserName[i], dataAvatar.getResourceId(i, -1), dataLocation[i], dataRepository[i], dataCompany[i], dataFollowers[i], dataFollowing[i])
            listUser.add(user)
        }
        return listUser
    }

    private fun showRecycleList(){
        binding.rvUser.layoutManager = LinearLayoutManager(this)
        val listUserAdapater = ListUserAdapater(list)
        binding.rvUser.adapter = listUserAdapater

        listUserAdapater.setOnItemClickCallback(object : ListUserAdapater.OnItemClickCallback {
            override fun onItemClicked(data: User) {
                ShowSelectedUser(data)
            }
        })
    }

    private fun ShowSelectedUser(User: User) {
        Toast.makeText(this, "Kamu memilih " + User.name, Toast.LENGTH_SHORT).show()
        val user = User
        val moveWithObjectIntent = Intent(this@MainActivity, MoveActivity::class.java)
        moveWithObjectIntent.putExtra(MoveActivity.EXTRA_USER, user)
        startActivity(moveWithObjectIntent)
    }

    private fun searchUser(){
        binding.apply {
            val query = etQuery.text.toString()
            if(query.isEmpty()) return
            showLoading(true)
            viewModel.setSearchUser(query)
        }
    }

    private fun showLoading(state:Boolean){
        if(state){
            binding.progressBar.visibility = View.VISIBLE
        }else{
            binding.progressBar.visibility = View.GONE
        }
    }

}