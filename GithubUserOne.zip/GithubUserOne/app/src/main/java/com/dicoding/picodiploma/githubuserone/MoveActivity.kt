package com.dicoding.picodiploma.githubuserone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import de.hdodenhof.circleimageview.CircleImageView
import org.w3c.dom.Text


class MoveActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setTheme(R.style.Theme_GithubUserOne)
        setContentView(R.layout.activity_move)

        val User = intent.getParcelableExtra<User>(EXTRA_USER) as User


        val tvName:TextView = findViewById(R.id.tv_name)
        val tvUsername:TextView = findViewById(R.id.tv_username)
        val imgAvatar:ImageView = findViewById(R.id.img_avatar)
        val tvLocation:TextView = findViewById(R.id.tv_location)
        val tvRepository:TextView = findViewById(R.id.tv_repository)
        val tvCompany:TextView = findViewById(R.id.tv_company)
        val tvFollowers:TextView = findViewById(R.id.tv_followers)
        val tvFollowing:TextView = findViewById(R.id.tv_following)



        val name = "${User.name.toString()}"
        val username = "${User.username.toString()}"
        val location = "Location: ${User.location.toString()}"
        val repository = "${User.repository.toString()} Repository"
        val company = "Company: ${User.company.toString()}"
        val followers = "${User.followers.toString()} Followers"
        val following = "${User.following.toString()} Following"

        tvName.text = name
        tvUsername.text = username
        tvLocation.text = location
        tvRepository.text = repository
        tvCompany.text = company
        tvFollowers.text = followers
        tvFollowing.text = following
        imgAvatar.setImageResource(User.avatar)

    }

    companion object {
        val EXTRA_USER = "extra_user"
    }

}