package com.dicoding.picodiploma.githubuserone

data class UserResponse(
    val items : ArrayList<User>
)
