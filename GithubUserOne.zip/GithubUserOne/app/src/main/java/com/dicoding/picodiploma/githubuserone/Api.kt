package com.dicoding.picodiploma.githubuserone

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface Api {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUsers(
        @Query("q") query: String
    ):Call<UserResponse>
}